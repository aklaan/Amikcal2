package com.rdupuis.gamingtools.interfaces;

public interface Clikable {

	public void onClick();
}
