package com.rdupuis.gamingtools.animations;

import java.util.EventListener;

/**
 * Created by rodol on 12/10/2015.
 */
public interface AnimationManagerListener extends EventListener {


public void onStopPlaying();
public void onStartPlaying();

}
