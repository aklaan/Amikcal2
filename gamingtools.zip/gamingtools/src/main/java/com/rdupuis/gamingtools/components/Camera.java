package com.rdupuis.gamingtools.components;

public class Camera {
float centerX=0;
float centerY=0;
float centerZ=0;

float eyeX=0;
float eyeY=0;
float eyeZ=0;

float orientX=0;
float orientY=1;
float orientZ=0;


}
