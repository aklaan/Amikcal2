package com.rdupuis.gamingtools.interfaces;

public interface Drawable {

	public void draw();
}
