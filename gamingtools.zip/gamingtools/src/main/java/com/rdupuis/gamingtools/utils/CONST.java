package com.rdupuis.gamingtools.utils;

import com.rdupuis.gamingtools.components.Vertex;

/**
 * Created by rodol on 25/11/2015.
 */
public final class CONST {
    public static final int FLOAT_SIZE = Float.SIZE / Byte.SIZE;
    public static final int SHORT_SIZE = Short.SIZE/Byte.SIZE;

}
