package com.rdupuis.gamingtools.shaders;

/**
 * Created by rodol on 16/12/2015.
 */
public abstract class AbstractProgramShader {

public abstract void enableAttribs();

public abstract void disableAttribs();

    public abstract void initLocations();

    public abstract void initCode();
}
