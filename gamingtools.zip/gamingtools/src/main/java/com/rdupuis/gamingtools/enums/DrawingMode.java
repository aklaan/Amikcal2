package com.rdupuis.gamingtools.enums;

public enum DrawingMode {
	FILL,EMPTY
}
