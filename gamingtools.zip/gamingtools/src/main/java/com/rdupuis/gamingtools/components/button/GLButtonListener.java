package com.rdupuis.gamingtools.components.button;

import java.util.EventListener;

/**
 * Created by rodol on 12/10/2015.
 */
public interface GLButtonListener extends EventListener {


public void onClick();

    public void onLongClick();
}
